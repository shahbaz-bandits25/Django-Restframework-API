from django.urls import path

from .views import studntList


app_name = "myapp"


urlpatterns = [
    path('myapp/', studntList.as_view()),
]